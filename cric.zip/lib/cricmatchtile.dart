// ignore_for_file: prefer_const_constructors, unnecessary_null_comparison, prefer_conditional_assignment, use_key_in_widget_constructors

import 'package:flutter/material.dart';
import 'package:shop/cricketjson.dart';
import 'package:shop/cricmatch.dart';
import '/soccer.dart';

class cricmatchtile extends StatelessWidget {
  cricketapi match;
  int ind;
  cricmatchtile(this.match, this.ind);

  get controller => null;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      controller: controller,
      child: Container(
          height: 550,
          child: ListView.builder(
              itemBuilder: (context, index) {
                return cricmatch(
                    match.seriesAdWrapper[ind].seriesMatches.matches, index);
              },
              itemCount:
                  match.seriesAdWrapper[ind].seriesMatches.matches.length)),
    );
    // Container(
    //     height: 10,
    //     margin: EdgeInsets.symmetric(vertical: 12.0),
    //     child: );
    //);
  }
}
